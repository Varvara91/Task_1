'use strict'
function getLess(){

		var num1 = prompt('Введите первое число');
		var num2 = prompt('Введите второе число');

	if (isNaN(+num1)){
		alert('Вы неправильно ввели первое число');
		var num1 = prompt('Введите первое число');
	} else if (isNaN(+num2)){
		alert('Вы неправильно ввели второе число');
		var num2 = prompt('Введите второе число');
	}
		if ((+num1)==(+num2)) return document.getElementById("button1").innerHTML = 'Они равны';
		var result = (+num1)>(+num2) ? num2:num1;
		return document.getElementById("button1").innerHTML = result;
}

/////////////////////////////////////////////////////////////////////////////
function countBs(){
	var str = prompt('Ввод строки', 'BnmBBbL');
	var k=0;
	for (var i=0; i<=str.length; i++) {
		if(str.charAt(i)=='B'){
				k++
		}else continue;
	} 
	if (k==0) return document.getElementById("button2").innerHTML = 'Не обнаружено';
	return document.getElementById("button2").innerHTML = k;
}

/////////////////////////////////////////////////////////////////////////////
function countChar(){
	var strUser = prompt('Ввод строки');
	var symUser = prompt('Ввод символа');
	var c=0;
	for (var n=0; n<=strUser.length; n++) {
		if(strUser.charAt(n)==symUser){
				c++
		}else continue;
	} 
	if (c==0) return document.getElementById("button3").innerHTML = 'Не обнаружено';
	return document.getElementById("button3").innerHTML = c;
}

/////////////////////////////////////////////////////////////////////////////
	
var x= 'Строка';
		function isEven(x){
		while (isNaN(x)) {
			alert('Нужно ввести число!');
			var x = +prompt('Введите число','50');
		}
		  if (x == 0)
		    return document.getElementById("button4").innerHTML = 'true';
		  else if (x == 1)
		    return document.getElementById("button4").innerHTML = 'false';
		  else if (x < 0)
		    return isEven(-x);
		  else
		    return isEven(x - 2);
		}

var obj = {
	name: "Varya",
	age: 25
}
console.log(obj[1]);	